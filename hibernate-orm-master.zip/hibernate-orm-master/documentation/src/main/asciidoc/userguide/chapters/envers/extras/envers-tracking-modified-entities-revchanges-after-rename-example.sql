insert
into
    REVCHANGES
    (REV, ENTITYNAME)
values
    (?, ?)

-- binding parameter [1] as [INTEGER] - [1]
-- binding parameter [2] as [VARCHAR] - [org.hibernate.userguide.envers.EntityTypeChangeAuditTest$Customer]
